package com.example.musik

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
